"""
main.py
Entry point for FinanceFlow - Personal Finance Tracker (OOP Desktop App).
Run with: python main.py
"""

import tkinter as tk
import sys
import os

# Ensure the project root is on the import path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from controllers.app_controller import AppController
from views.main_window import MainWindow


def main():
    root = tk.Tk()
    controller = AppController()
    app = MainWindow(root, controller)
    root.mainloop()


if __name__ == "__main__":
    main()