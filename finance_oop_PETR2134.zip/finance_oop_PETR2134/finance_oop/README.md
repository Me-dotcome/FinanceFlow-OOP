# FinanceFlow - OOP Desktop Application
### PETR2134 · Object Oriented Programming · Foundation Degree in Software Engineering

A Python/Tkinter GUI application for personal finance management, demonstrating all four OOP principles (Encapsulation, Abstraction, Inheritance, Polymorphism) alongside Factory, Singleton, Repository, and MVC design patterns.

---

## Screenshot

The application uses a dark theme with purple accents. The main window shows three summary cards (Balance, Income, Expenses), a scrollable transaction table with colour-coded rows, quick-action buttons, and a real-time budget status panel.

---

## Features

- **Dashboard** — monthly balance, income, and expense summary cards with over-budget alerts
- **Transaction Management** — full CRUD (Create, Read, Update, Delete) for income and expense transactions
- **Budget Management** — set monthly per-category spending limits with visual progress indicators
- **Multiple Windows** — dashboard, transaction list, add/edit dialog, budget window
- **Input Validation** — validated property setters on all model classes
- **JSON Persistence** — data stored locally in `data/finance_data.json`
- **Unit Tests** — 30 tests, all passing (pytest)

---

## OOP Principles Demonstrated

| Principle | Where |
|---|---|
| **Encapsulation** | Private `_amount`, `_category`, `_date` fields with `@property` validated setters in `BaseTransaction` |
| **Abstraction** | `BaseTransaction` (ABC) defines abstract `get_type()` and `get_signed_amount()` methods |
| **Inheritance** | `Income` and `Expense` both extend `BaseTransaction` |
| **Polymorphism** | `sum(t.get_signed_amount() for t in txns)` works for any mix of `Income`/`Expense` objects |

---

## Design Patterns

- **Factory** — `TransactionFactory.create()` returns correct subclass by type string
- **Singleton** — `DataStore.__new__()` ensures one data store instance per session
- **Repository** — `DataStore` abstracts all JSON persistence behind a CRUD API
- **MVC** — `models/`, `controllers/`, `views/` directories with no cross-layer coupling

---

## Project Structure

```
finance_oop/
├── main.py                          # Entry point
├── models/
│   ├── base_transaction.py          # Abstract base class
│   ├── transaction.py               # Income, Expense, TransactionFactory
│   └── budget.py                    # Budget model
├── controllers/
│   ├── app_controller.py            # Business logic layer
│   └── data_store.py                # Singleton JSON persistence
├── views/
│   ├── main_window.py               # Dashboard / main window
│   ├── transaction_window.py        # All transactions list window
│   ├── add_edit_dialog.py           # Add / edit modal dialog
│   └── budget_window.py             # Budget management window
├── tests/
│   └── test_finance.py              # 30 unit tests (pytest)
└── data/
    └── finance_data.json            # Auto-created on first run
```

---

## Requirements

- Python 3.9 or higher
- Tkinter (included in standard Python on Windows/macOS; on Linux: `sudo apt install python3-tk`)
- pytest (for running tests): `pip install pytest`

---

## Running the Application

```bash
# Clone / download the project
cd finance_oop

# Run the application
python main.py
```

---

## Running the Tests

```bash
cd finance_oop
pip install pytest
python -m pytest tests/test_finance.py -v
```

### Test Output

```
============================= test session starts ==============================
collected 30 items

tests/test_finance.py::TestIncome::test_income_creation_valid          PASSED
tests/test_finance.py::TestIncome::test_income_signed_amount_positive  PASSED
tests/test_finance.py::TestIncome::test_income_negative_amount_raises  PASSED
tests/test_finance.py::TestIncome::test_income_zero_amount_raises      PASSED
tests/test_finance.py::TestIncome::test_income_amount_rounds_to_two_dp PASSED
tests/test_finance.py::TestIncome::test_income_invalid_date_raises     PASSED
tests/test_finance.py::TestIncome::test_income_to_dict_round_trip      PASSED
tests/test_finance.py::TestIncome::test_income_equality_by_id          PASSED
tests/test_finance.py::TestExpense::test_expense_creation_valid        PASSED
tests/test_finance.py::TestExpense::test_expense_signed_amount_negative PASSED
tests/test_finance.py::TestExpense::test_expense_invalid_amount_raises  PASSED
tests/test_finance.py::TestExpense::test_expense_to_dict_round_trip    PASSED
tests/test_finance.py::TestExpense::test_expense_invalid_category_falls_back_to_other PASSED
tests/test_finance.py::TestTransactionFactory::test_factory_creates_income    PASSED
tests/test_finance.py::TestTransactionFactory::test_factory_creates_expense   PASSED
tests/test_finance.py::TestTransactionFactory::test_factory_raises_on_unknown_type PASSED
tests/test_finance.py::TestTransactionFactory::test_factory_from_dict_income  PASSED
tests/test_finance.py::TestTransactionFactory::test_factory_from_dict_expense PASSED
tests/test_finance.py::TestBudget::test_budget_creation_valid          PASSED
tests/test_finance.py::TestBudget::test_budget_remaining_calculated    PASSED
tests/test_finance.py::TestBudget::test_budget_is_exceeded             PASSED
tests/test_finance.py::TestBudget::test_budget_not_exceeded            PASSED
tests/test_finance.py::TestBudget::test_budget_percent_used            PASSED
tests/test_finance.py::TestBudget::test_budget_reset_spending          PASSED
tests/test_finance.py::TestBudget::test_budget_invalid_limit_raises    PASSED
tests/test_finance.py::TestBudget::test_budget_invalid_category_raises PASSED
tests/test_finance.py::TestBudget::test_budget_to_dict_round_trip      PASSED
tests/test_finance.py::TestPolymorphism::test_get_type_polymorphic     PASSED
tests/test_finance.py::TestPolymorphism::test_signed_amounts_sum_to_balance PASSED
tests/test_finance.py::TestPolymorphism::test_sorting_by_date          PASSED

============================== 30 passed in 0.04s ==============================
```

---

## References

- Python abc module: https://docs.python.org/3/library/abc.html
- Gamma et al. (1994) *Design Patterns: Elements of Reusable Object-Oriented Software*
- pytest documentation: https://docs.pytest.org
