"""
transaction.py
Concrete transaction types: Income and Expense.
Demonstrates: Inheritance, Polymorphism
"""

from models.base_transaction import BaseTransaction


class Income(BaseTransaction):
    """
    Represents a credit / income transaction.
    Inherits from BaseTransaction and provides income-specific behaviour.
    """

    INCOME_CATEGORIES = ["Salary", "Freelance", "Savings", "Other"]

    def __init__(self, amount: float, description: str, category: str, date: str = None):
        # Restrict to income-relevant categories
        if category not in self.INCOME_CATEGORIES:
            category = "Other"
        super().__init__(amount, description, category, date)

    def get_type(self) -> str:
        """Polymorphic: returns 'Income' label."""
        return "Income"

    def get_signed_amount(self) -> float:
        """Polymorphic: income is a positive contribution to balance."""
        return +self._amount

    @classmethod
    def from_dict(cls, data: dict) -> "Income":
        """Reconstruct an Income object from a stored dictionary."""
        obj = cls.__new__(cls)
        obj._id = data["id"]
        obj._amount = data["amount"]
        obj.description = data["description"]
        obj._category = data["category"]
        obj._date = data["date"]
        obj._created_at = data.get("created_at", "")
        return obj


class Expense(BaseTransaction):
    """
    Represents a debit / expense transaction.
    Inherits from BaseTransaction and provides expense-specific behaviour.
    """

    EXPENSE_CATEGORIES = [
        "Food & Groceries", "Bills & Utilities", "Entertainment",
        "Transport", "Healthcare", "Clothing", "Other"
    ]

    def __init__(self, amount: float, description: str, category: str, date: str = None):
        if category not in self.EXPENSE_CATEGORIES:
            category = "Other"
        super().__init__(amount, description, category, date)

    def get_type(self) -> str:
        """Polymorphic: returns 'Expense' label."""
        return "Expense"

    def get_signed_amount(self) -> float:
        """Polymorphic: expense is a negative contribution to balance."""
        return -self._amount

    @classmethod
    def from_dict(cls, data: dict) -> "Expense":
        """Reconstruct an Expense object from a stored dictionary."""
        obj = cls.__new__(cls)
        obj._id = data["id"]
        obj._amount = data["amount"]
        obj.description = data["description"]
        obj._category = data["category"]
        obj._date = data["date"]
        obj._created_at = data.get("created_at", "")
        return obj


class TransactionFactory:
    """
    Factory Pattern: creates the correct transaction subclass
    based on a type string. Demonstrates additional design pattern usage.
    """

    @staticmethod
    def create(t_type: str, amount: float, description: str,
               category: str, date: str = None) -> BaseTransaction:
        """
        Create a transaction of the appropriate subtype.

        Args:
            t_type (str): 'Income' or 'Expense'
            amount (float): Positive monetary value.
            description (str): Description text.
            category (str): Category label.
            date (str): Optional ISO date string.

        Returns:
            BaseTransaction: Income or Expense instance.

        Raises:
            ValueError: If t_type is unrecognised.
        """
        if t_type == "Income":
            return Income(amount, description, category, date)
        elif t_type == "Expense":
            return Expense(amount, description, category, date)
        else:
            raise ValueError(f"Unknown transaction type: {t_type}")

    @staticmethod
    def from_dict(data: dict) -> BaseTransaction:
        """Reconstruct a transaction from a stored dictionary using type dispatch."""
        t_type = data.get("type")
        if t_type == "Income":
            return Income.from_dict(data)
        elif t_type == "Expense":
            return Expense.from_dict(data)
        else:
            raise ValueError(f"Cannot reconstruct unknown type: {t_type}")
