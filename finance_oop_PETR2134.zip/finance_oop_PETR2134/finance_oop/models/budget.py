"""
budget.py
Budget model – sets a monthly spending limit per category.
Demonstrates: Encapsulation, Observer-lite notification via callbacks
"""

from datetime import datetime
from models.base_transaction import BaseTransaction


class Budget:
    """
    Represents a monthly budget limit for a given spending category.
    Stores a limit and tracks spent amount against it.
    """

    def __init__(self, category: str, limit: float, month: str = None):
        """
        Initialise a Budget.

        Args:
            category (str): Category this budget applies to.
            limit (float): Maximum amount allowed for the month.
            month (str): 'YYYY-MM' string. Defaults to current month.
        """
        if category not in BaseTransaction.CATEGORIES:
            raise ValueError(f"Invalid category: {category}")
        if limit <= 0:
            raise ValueError("Budget limit must be a positive number.")

        self._category = category
        self._limit = round(float(limit), 2)
        self._month = month if month else datetime.today().strftime("%Y-%m")
        self._spent = 0.0

    # ---------- Properties ----------

    @property
    def category(self) -> str:
        return self._category

    @property
    def limit(self) -> float:
        return self._limit

    @limit.setter
    def limit(self, value: float):
        if value <= 0:
            raise ValueError("Budget limit must be positive.")
        self._limit = round(float(value), 2)

    @property
    def month(self) -> str:
        return self._month

    @property
    def spent(self) -> float:
        return self._spent

    @property
    def remaining(self) -> float:
        return round(self._limit - self._spent, 2)

    @property
    def is_exceeded(self) -> bool:
        return self._spent > self._limit

    @property
    def percent_used(self) -> float:
        if self._limit == 0:
            return 0.0
        return round((self._spent / self._limit) * 100, 1)

    # ---------- Methods ----------

    def add_spending(self, amount: float):
        """Add to the amount spent this month."""
        if amount < 0:
            raise ValueError("Spending amount must be non-negative.")
        self._spent = round(self._spent + amount, 2)

    def reset_spending(self):
        """Reset spent amount (e.g. when recalculating from transactions)."""
        self._spent = 0.0

    def to_dict(self) -> dict:
        return {
            "category": self._category,
            "limit": self._limit,
            "month": self._month,
            "spent": self._spent
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Budget":
        obj = cls.__new__(cls)
        obj._category = data["category"]
        obj._limit = data["limit"]
        obj._month = data["month"]
        obj._spent = data.get("spent", 0.0)
        return obj

    def __repr__(self) -> str:
        return (f"Budget(category={self._category}, limit={self._limit}, "
                f"spent={self._spent}, month={self._month})")
