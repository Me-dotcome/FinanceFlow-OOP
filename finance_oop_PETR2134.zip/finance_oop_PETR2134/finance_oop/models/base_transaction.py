"""
base_transaction.py
Abstract base class for all financial transaction types.
Demonstrates: Abstraction, Encapsulation
"""

from abc import ABC, abstractmethod
from datetime import datetime
import uuid


class BaseTransaction(ABC):
    """
    Abstract base class representing a generic financial transaction.
    All transaction types must inherit from this class and implement
    the abstract methods defined here.
    """

    CATEGORIES = [
        "Food & Groceries",
        "Bills & Utilities",
        "Entertainment",
        "Transport",
        "Healthcare",
        "Clothing",
        "Savings",
        "Salary",
        "Freelance",
        "Other"
    ]

    def __init__(self, amount: float, description: str, category: str, date: str = None):
        """
        Initialise a BaseTransaction.

        Args:
            amount (float): Monetary value of the transaction (must be positive).
            description (str): Human-readable description of the transaction.
            category (str): Category from CATEGORIES list.
            date (str): ISO date string (YYYY-MM-DD). Defaults to today.

        Raises:
            ValueError: If amount is not positive or category is invalid.
        """
        self._id = str(uuid.uuid4())
        self.amount = amount          # uses setter for validation
        self.description = description
        self.category = category      # uses setter for validation
        self._date = date if date else datetime.today().strftime("%Y-%m-%d")
        self._created_at = datetime.now().isoformat()

    # ---------- Properties (Encapsulation) ----------

    @property
    def id(self) -> str:
        return self._id

    @property
    def amount(self) -> float:
        return self._amount

    @amount.setter
    def amount(self, value: float):
        if not isinstance(value, (int, float)) or value <= 0:
            raise ValueError("Amount must be a positive number.")
        self._amount = round(float(value), 2)

    @property
    def category(self) -> str:
        return self._category

    @category.setter
    def category(self, value: str):
        if value not in self.CATEGORIES:
            raise ValueError(f"Category must be one of: {', '.join(self.CATEGORIES)}")
        self._category = value

    @property
    def date(self) -> str:
        return self._date

    @date.setter
    def date(self, value: str):
        try:
            datetime.strptime(value, "%Y-%m-%d")
        except ValueError:
            raise ValueError("Date must be in YYYY-MM-DD format.")
        self._date = value

    @property
    def created_at(self) -> str:
        return self._created_at

    # ---------- Abstract Methods ----------

    @abstractmethod
    def get_type(self) -> str:
        """Return the transaction type label (e.g. 'Income' or 'Expense')."""
        pass

    @abstractmethod
    def get_signed_amount(self) -> float:
        """Return the amount with appropriate sign (+/-) for balance calculations."""
        pass

    # ---------- Concrete Methods ----------

    def to_dict(self) -> dict:
        """Serialise transaction to a dictionary for storage."""
        return {
            "id": self._id,
            "type": self.get_type(),
            "amount": self._amount,
            "description": self.description,
            "category": self._category,
            "date": self._date,
            "created_at": self._created_at
        }

    @classmethod
    def from_dict(cls, data: dict):
        """
        Factory method – reconstruct a transaction from a stored dictionary.
        Subclasses override this to restore the correct type.
        """
        raise NotImplementedError("Subclasses must implement from_dict()")

    def __repr__(self) -> str:
        return (f"{self.__class__.__name__}(id={self._id[:8]}, "
                f"amount={self._amount}, category={self._category}, date={self._date})")

    def __eq__(self, other) -> bool:
        if not isinstance(other, BaseTransaction):
            return False
        return self._id == other._id

    def __lt__(self, other) -> bool:
        """Allow sorting transactions by date."""
        return self._date < other._date
