"""
app_controller.py
Application controller  mediates between the GUI views and the data layer.
Demonstrates: MVC Controller, Single Responsibility Principle
"""

from datetime import datetime
from typing import List, Tuple
from controllers.data_store import DataStore
from models.transaction import TransactionFactory, Income, Expense
from models.base_transaction import BaseTransaction
from models.budget import Budget


class AppController:
    """
    Central controller for the Personal Finance Tracker.
    All business logic lives here; views call controller methods and
    the controller calls the DataStore.
    """

    def __init__(self):
        self._store = DataStore()

    # ---------- Transaction Operations ----------

    def add_transaction(self, t_type: str, amount: float, description: str,
                        category: str, date: str = None) -> Tuple[bool, str]:
        """
        Validate inputs and add a new transaction.

        Returns:
            (True, transaction_id) on success, or (False, error_message) on failure.
        """
        try:
            if not description.strip():
                return False, "Description cannot be empty."
            t = TransactionFactory.create(t_type, amount, description.strip(), category, date)
            self._store.add_transaction(t)
            self._recalculate_budget_spending(t.category, t.date[:7])
            return True, t.id
        except ValueError as e:
            return False, str(e)

    def update_transaction(self, t_id: str, amount: float = None,
                           description: str = None, category: str = None,
                           date: str = None) -> Tuple[bool, str]:
        try:
            old = self._store.get_transaction_by_id(t_id)
            if old is None:
                return False, "Transaction not found."
            old_month = old.date[:7]
            old_category = old.category

            self._store.update_transaction(t_id, amount, description, category, date)

            updated = self._store.get_transaction_by_id(t_id)
            new_month = updated.date[:7]
            new_category = updated.category

            # Recalculate budgets for both old and new month/category combinations.
            self._recalculate_budget_spending(old_category, old_month)
            if new_month != old_month or new_category != old_category:
                self._recalculate_budget_spending(new_category, new_month)
            return True, "Transaction updated."
        except (ValueError, LookupError) as e:
            return False, str(e)

    def delete_transaction(self, t_id: str) -> Tuple[bool, str]:
        t = self._store.get_transaction_by_id(t_id)
        if t is None:
            return False, "Transaction not found."
        month = t.date[:7]
        category = t.category
        self._store.delete_transaction(t_id)
        self._recalculate_budget_spending(category, month)
        return True, "Transaction deleted."

    def get_all_transactions(self) -> List[BaseTransaction]:
        return self._store.get_all_transactions()

    def get_transaction_by_id(self, t_id: str):
        return self._store.get_transaction_by_id(t_id)

    # ---------- Budget Operations ----------

    def set_budget(self, category: str, limit: float,
                   month: str = None) -> Tuple[bool, str]:
        try:
            if month is None:
                month = datetime.today().strftime("%Y-%m")
            budget = Budget(category, limit, month)
            self._store.add_or_update_budget(budget)
            self._recalculate_budget_spending(category, month)
            return True, "Budget saved."
        except ValueError as e:
            return False, str(e)

    def delete_budget(self, category: str, month: str) -> Tuple[bool, str]:
        self._store.delete_budget(category, month)
        return True, "Budget removed."

    def get_all_budgets(self) -> List[Budget]:
        return self._store.get_all_budgets()

    def get_budgets_for_month(self, month: str) -> List[Budget]:
        budgets = [b for b in self._store.get_all_budgets() if b.month == month]
        # Recalculate spending from transactions each time
        for b in budgets:
            self._recalculate_budget_spending(b.category, b.month)
        return budgets

    # ---------- Summary / Dashboard ----------

    def get_dashboard_summary(self, month: str = None) -> dict:
        """Return key financial metrics for the given month."""
        if month is None:
            month = datetime.today().strftime("%Y-%m")
        income = self._store.get_monthly_total_income(month)
        expenses = self._store.get_monthly_total_expenses(month)
        balance = self._store.get_monthly_balance(month)
        by_category = self._store.get_spending_by_category(month)
        budgets = self.get_budgets_for_month(month)
        alerts = [b for b in budgets if b.is_exceeded]

        return {
            "month": month,
            "income": income,
            "expenses": expenses,
            "balance": balance,
            "by_category": by_category,
            "budgets": budgets,
            "budget_alerts": alerts,
        }

    def get_available_months(self) -> List[str]:
        """Return sorted list of unique YYYY-MM months from all transactions."""
        months = sorted(
            {t.date[:7] for t in self._store.get_all_transactions()},
            reverse=True
        )
        current = datetime.today().strftime("%Y-%m")
        if current not in months:
            months.insert(0, current)
        return months

    # ---------- Internal Helpers ----------

    def _recalculate_budget_spending(self, category: str, month: str):
        """Recalculate and persist spending for a specific budget after any change."""
        budget = self._store.get_budget(category, month)
        if budget is None:
            return
        budget.reset_spending()
        for t in self._store.get_transactions_by_month(month):
            if t.get_type() == "Expense" and t.category == category:
                budget.add_spending(t.amount)
        self._store.save()
