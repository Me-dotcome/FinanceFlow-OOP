"""
data_store.py
Repository pattern – single source of truth for transactions and budgets.
Handles JSON persistence to disk.
Demonstrates: Design Pattern (Repository), Encapsulation
"""

import json
import os
from typing import List, Optional
from models.transaction import TransactionFactory
from models.base_transaction import BaseTransaction
from models.budget import Budget


DATA_FILE = os.path.join(os.path.dirname(__file__), "..", "data", "finance_data.json")


class DataStore:
    """
    Singleton-style repository that loads, stores, and persists all
    financial data (transactions and budgets) to a local JSON file.
    """

    _instance = None  # Singleton instance reference

    def __new__(cls):
        """Ensure only one DataStore instance exists (Singleton Pattern)."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialised = False
        return cls._instance

    def __init__(self):
        if self._initialised:
            return
        self._transactions: List[BaseTransaction] = []
        self._budgets: List[Budget] = []
        self._ensure_data_dir()
        self._load()
        self._initialised = True

    # ---------- Setup ----------

    def _ensure_data_dir(self):
        os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)

    def _load(self):
        """Load data from the JSON file if it exists."""
        if not os.path.exists(DATA_FILE):
            return
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                raw = json.load(f)
            self._transactions = [
                TransactionFactory.from_dict(t) for t in raw.get("transactions", [])
            ]
            self._budgets = [
                Budget.from_dict(b) for b in raw.get("budgets", [])
            ]
        except (json.JSONDecodeError, KeyError) as e:
            print(f"[DataStore] Warning: Could not load data file – {e}")

    def save(self):
        """Persist all data to the JSON file."""
        data = {
            "transactions": [t.to_dict() for t in self._transactions],
            "budgets": [b.to_dict() for b in self._budgets]
        }
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    # ---------- Transaction CRUD ----------

    def add_transaction(self, transaction: BaseTransaction):
        self._transactions.append(transaction)
        self.save()

    def get_all_transactions(self) -> List[BaseTransaction]:
        return sorted(self._transactions, reverse=True)

    def get_transaction_by_id(self, t_id: str) -> Optional[BaseTransaction]:
        return next((t for t in self._transactions if t.id == t_id), None)

    def update_transaction(self, t_id: str, amount: float = None,
                           description: str = None, category: str = None,
                           date: str = None):
        """Update mutable fields on an existing transaction."""
        t = self.get_transaction_by_id(t_id)
        if t is None:
            raise LookupError(f"No transaction found with id {t_id}")
        if amount is not None:
            t.amount = amount
        if description is not None:
            t.description = description
        if category is not None:
            t.category = category
        if date is not None:
            t.date = date
        self.save()

    def delete_transaction(self, t_id: str):
        self._transactions = [t for t in self._transactions if t.id != t_id]
        self.save()

    # ---------- Budget CRUD ----------

    def add_or_update_budget(self, budget: Budget):
        """Upsert a budget: replace existing same-category+month, or add new."""
        existing = self.get_budget(budget.category, budget.month)
        if existing:
            self._budgets.remove(existing)
        self._budgets.append(budget)
        self.save()

    def get_budget(self, category: str, month: str) -> Optional[Budget]:
        return next(
            (b for b in self._budgets
             if b.category == category and b.month == month),
            None
        )

    def get_all_budgets(self) -> List[Budget]:
        return list(self._budgets)

    def delete_budget(self, category: str, month: str):
        self._budgets = [
            b for b in self._budgets
            if not (b.category == category and b.month == month)
        ]
        self.save()

    # ---------- Summary Queries ----------

    def get_transactions_by_month(self, month: str) -> List[BaseTransaction]:
        """Return all transactions for a given 'YYYY-MM' month string."""
        return [t for t in self._transactions if t.date.startswith(month)]

    def get_monthly_total_income(self, month: str) -> float:
        return round(sum(
            t.get_signed_amount()
            for t in self.get_transactions_by_month(month)
            if t.get_type() == "Income"
        ), 2)

    def get_monthly_total_expenses(self, month: str) -> float:
        return round(sum(
            abs(t.get_signed_amount())
            for t in self.get_transactions_by_month(month)
            if t.get_type() == "Expense"
        ), 2)

    def get_monthly_balance(self, month: str) -> float:
        return round(sum(
            t.get_signed_amount() for t in self.get_transactions_by_month(month)
        ), 2)

    def get_spending_by_category(self, month: str) -> dict:
        """Return a dict of {category: total_spent} for expense transactions."""
        result = {}
        for t in self.get_transactions_by_month(month):
            if t.get_type() == "Expense":
                result[t.category] = round(result.get(t.category, 0) + t.amount, 2)
        return result
