import tkinter as tk
from tkinter import font as tkfont


def _draw_rounded_rect(canvas, x1, y1, x2, y2, r, **kwargs):
    if r > min((x2 - x1) / 2, (y2 - y1) / 2):
        r = min((x2 - x1) / 2, (y2 - y1) / 2)
    canvas.create_arc(x1, y1, x1 + 2 * r, y1 + 2 * r,
                      start=90, extent=90, style="pieslice",
                      **kwargs)
    canvas.create_arc(x2 - 2 * r, y1, x2, y1 + 2 * r,
                      start=0, extent=90, style="pieslice",
                      **kwargs)
    canvas.create_arc(x1, y2 - 2 * r, x1 + 2 * r, y2,
                      start=180, extent=90, style="pieslice",
                      **kwargs)
    canvas.create_arc(x2 - 2 * r, y2 - 2 * r, x2, y2,
                      start=270, extent=90, style="pieslice",
                      **kwargs)
    canvas.create_rectangle(x1 + r, y1, x2 - r, y2, **kwargs)
    canvas.create_rectangle(x1, y1 + r, x2, y2 - r, **kwargs)


class RoundedFrame(tk.Canvas):
    def __init__(self, parent, bg="#000000", corner_radius=14,
                 padding=2, shadow=False, shadow_offset=5,
                 shadow_color="#1A1730", **kwargs):
        super().__init__(parent,
                         bg=parent.cget("bg"),
                         highlightthickness=0,
                         **kwargs)
        self._bg_color = bg
        self._corner_radius = corner_radius
        self._padding = padding
        self._shadow = shadow
        self._shadow_offset = shadow_offset
        self._shadow_color = shadow_color
        self.body = tk.Frame(self, bg=bg)
        self._body_window = self.create_window(
            (padding, padding), window=self.body,
            anchor="nw",
            width=0, height=0,
            tags=("body",)
        )
        self.bind("<Configure>", self._on_configure)

    def _on_configure(self, event=None):
        self.delete("bg")
        self.delete("shadow")
        width = event.width if event else self.winfo_width()
        height = event.height if event else self.winfo_height()
        if width <= 1 or height <= 1:
            self.after(10, self._on_configure)
            return

        so = self._shadow_offset if self._shadow else 0

        if self._shadow:
            # Shadow offset to the LEFT and BOTTOM: shadow drawn at x-(so), y+(so)
            _draw_rounded_rect(self, 0, so, width - so, height,
                               self._corner_radius,
                               fill=self._shadow_color,
                               outline=self._shadow_color,
                               tags=("shadow",))

        # Card face shifted right so shadow peeks out on the left and bottom
        _draw_rounded_rect(self, so, 0, width, height - so,
                           self._corner_radius,
                           fill=self._bg_color,
                           outline=self._bg_color,
                           tags=("bg",))

        # Body sits inside the card face
        body_x = so + self._padding
        inner_width  = max(width  - so - 2 * self._padding, 0)
        inner_height = max(height - so - 2 * self._padding, 0)
        self.coords("body", body_x, self._padding)
        self.itemconfig("body", width=inner_width, height=inner_height)


class RoundedButton(tk.Canvas):
    def __init__(self, parent, text, command=None,
                 bg="#7C6AF7", fg="white",
                 activebackground=None, activeforeground=None,
                 font=("Helvetica", 10, "bold"), padx=14, pady=6,
                 corner_radius=14, shadow=False, shadow_offset=4,
                 shadow_color="#1A1730", **kwargs):
        self._text = text
        self._command = command
        self._bg = bg
        self._fg = fg
        self._active_bg = activebackground or bg
        self._active_fg = activeforeground or fg
        self._font = font
        self._padx = padx
        self._pady = pady
        self._corner_radius = corner_radius
        self._shadow = shadow
        self._shadow_offset = shadow_offset if shadow else 0
        self._shadow_color = shadow_color

        font_obj = tkfont.Font(font=font)
        text_width = font_obj.measure(text)
        text_height = font_obj.metrics("linespace")
        # Extra canvas space to accommodate the shadow offset
        width  = text_width  + (padx * 2) + self._shadow_offset
        height = text_height + (pady * 2) + self._shadow_offset

        super().__init__(parent,
                         width=width,
                         height=height,
                         bg=parent.cget("bg"),
                         highlightthickness=0,
                         cursor="hand2",
                         **kwargs)

        self._text_id = None
        self.bind("<Configure>", self._draw)
        self.bind("<ButtonPress-1>",   self._on_press)
        self.bind("<ButtonRelease-1>", self._on_release)
        self.bind("<Enter>", lambda e: self._set_colors(self._active_bg, self._fg))
        self.bind("<Leave>", lambda e: self._set_colors(self._bg, self._fg))

    def _set_colors(self, bg, fg):
        self._bg = bg
        self._fg = fg
        self._draw()

    def _draw(self, event=None):
        self.delete("all")
        width = self.winfo_width()
        height = self.winfo_height()
        if width <= 0 or height <= 0:
            return
        so = self._shadow_offset
        if so > 0:
            # Shadow on left and bottom
            _draw_rounded_rect(self, 0, so, width - so, height,
                               self._corner_radius,
                               fill=self._shadow_color,
                               outline=self._shadow_color)
        # Button face shifted right so shadow shows on the left
        _draw_rounded_rect(self, so, 0, width, height - so,
                           self._corner_radius,
                           fill=self._bg,
                           outline=self._bg)
        cx = (so + width) / 2
        cy = (height - so) / 2
        self._text_id = self.create_text(cx, cy,
                                          text=self._text,
                                          fill=self._fg,
                                          font=self._font)

    def _draw_pressed(self):
        """Pressed state: face slides into the shadow position, no shadow visible."""
        self.delete("all")
        width = self.winfo_width()
        height = self.winfo_height()
        if width <= 0 or height <= 0:
            return
        so = self._shadow_offset
        # Face moves left and down to the shadow's former position
        _draw_rounded_rect(self, 0, so, width - so, height,
                           self._corner_radius,
                           fill=self._bg,
                           outline=self._bg)
        cx = (width - so) / 2
        cy = (so + height) / 2
        self.create_text(cx, cy,
                         text=self._text,
                         fill=self._fg,
                         font=self._font)

    def _on_press(self, event=None):
        self._draw_pressed()

    def _on_release(self, _event=None):
        self._draw()
        if callable(self._command):
            self._command()
