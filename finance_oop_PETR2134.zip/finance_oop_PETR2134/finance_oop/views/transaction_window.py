"""
transaction_window.py
Secondary window – full transactions list with edit and delete.
Demonstrates: Multiple windows, CRUD UI, event-driven refresh.
"""

import tkinter as tk
from tkinter import ttk, messagebox
from controllers.app_controller import AppController
from views.add_edit_dialog import AddEditDialog
from views.rounded_widgets import RoundedButton, RoundedFrame

BG      = "#0F1117"
SURFACE = "#1C1F2B"
ACCENT  = "#7C6AF7"
SUCCESS = "#44CF6C"
DANGER  = "#F05D5E"
TEXT    = "#3E4157"
SUBTEXT = "#C6C8D3"
BORDER  = "#2A2D3E"
INPUT_BG = "#252837"


class TransactionWindow:
    """
    Displays all transactions in a scrollable table.
    Users can select a row and choose Edit or Delete.
    """

    def __init__(self, parent, controller: AppController, on_close=None):
        self._ctrl = controller
        self._on_close = on_close

        self.top = tk.Toplevel(parent)
        self.top.title("All Transactions")
        self.top.geometry("820x540")
        self.top.configure(bg=BG)
        self.top.protocol("WM_DELETE_WINDOW", self._close)

        self._setup_styles()
        self._build_ui()
        self.refresh()

    def _setup_styles(self):
        style = ttk.Style()
        style.configure("Treeview",
                        background=SURFACE, foreground=TEXT,
                        fieldbackground=SURFACE, rowheight=28)
        style.configure("Treeview.Heading",
                        background=BORDER, foreground=SUBTEXT,
                        font=("Helvetica", 9, "bold"))
        style.map("Treeview", background=[("selected", ACCENT)])

    def _build_ui(self):
        # Header
        header = tk.Frame(self.top, bg=SURFACE, height=50)
        header.pack(fill="x")
        tk.Label(header, text="All Transactions",
                 bg=SURFACE, fg=TEXT,
                 font=("Helvetica", 13, "bold")).pack(side="left", padx=20, pady=12)

        # Filter bar
        filter_frame = tk.Frame(self.top, bg=BG)
        filter_frame.pack(fill="x", padx=20, pady=(12, 0))

        tk.Label(filter_frame, text="Filter type:",
                 bg=BG, fg=SUBTEXT,
                 font=("Helvetica", 9)).pack(side="left")
        self._filter_var = tk.StringVar(value="All")
        for label in ("All", "Income", "Expense"):
            tk.Radiobutton(
                filter_frame, text=label, variable=self._filter_var,
                value=label, command=self.refresh,
                bg=BG, fg=TEXT, selectcolor=BG,
                activebackground=BG, activeforeground=ACCENT
            ).pack(side="left", padx=6)

        # Table
        table_frame = RoundedFrame(self.top, bg=SURFACE, corner_radius=14, padding=8)
        table_frame.pack(fill="both", expand=True, padx=20, pady=12)

        cols = ("Date", "Type", "Category", "Description", "Amount")
        self._tree = ttk.Treeview(table_frame, columns=cols,
                                  show="headings", selectmode="browse")
        widths = {"Date": 90, "Type": 75, "Category": 130,
                  "Description": 260, "Amount": 100}
        for col in cols:
            self._tree.heading(col, text=col,
                               command=lambda c=col: self._sort_by(c))
            self._tree.column(col, width=widths.get(col, 100),
                              anchor="e" if col == "Amount" else "w")
        self._tree.tag_configure("income", foreground=SUCCESS)
        self._tree.tag_configure("expense", foreground=DANGER)

        sb = ttk.Scrollbar(table_frame, orient="vertical",
                           command=self._tree.yview)
        self._tree.configure(yscrollcommand=sb.set)
        self._tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        # Action buttons
        btn_frame = tk.Frame(self.top, bg=BG)
        btn_frame.pack(fill="x", padx=20, pady=(0, 16))

        for label, cmd, colour in [
            ("Edit Selected",   self._edit,   ACCENT),
            ("Delete Selected", self._delete, DANGER),
        ]:
            RoundedButton(
                btn_frame, text=label, command=cmd,
                bg=colour, fg="white",
                font=("Helvetica", 9, "bold"),
                padx=14, pady=5, corner_radius=14
            ).pack(side="left", padx=(0, 8))

    def refresh(self):
        for row in self._tree.get_children():
            self._tree.delete(row)

        f = self._filter_var.get()
        txns = self._ctrl.get_all_transactions()
        if f != "All":
            txns = [t for t in txns if t.get_type() == f]

        for t in txns:
            sign = "+" if t.get_type() == "Income" else "−"
            tag = "income" if t.get_type() == "Income" else "expense"
            self._tree.insert("", "end", iid=t.id, tags=(tag,), values=(
                t.date, t.get_type(), t.category,
                t.description[:50], f"{sign}£{t.amount:,.2f}"
            ))

    def _sort_by(self, col: str):
        """Sort tree by column header click."""
        data = [(self._tree.set(child, col), child)
                for child in self._tree.get_children("")]
        data.sort(reverse=False)
        for idx, (_, child) in enumerate(data):
            self._tree.move(child, "", idx)

    def _get_selected_id(self):
        sel = self._tree.selection()
        if not sel:
            messagebox.showinfo("Select a row",
                                "Please select a transaction first.",
                                parent=self.top)
            return None
        return sel[0]

    def _edit(self):
        t_id = self._get_selected_id()
        if t_id is None:
            return
        t = self._ctrl.get_transaction_by_id(t_id)
        if t:
            dlg = AddEditDialog(self.top, self._ctrl, existing=t)
            self.top.wait_window(dlg.top)
            self.refresh()

    def _delete(self):
        t_id = self._get_selected_id()
        if t_id is None:
            return
        if messagebox.askyesno("Confirm Delete",
                               "Are you sure you want to delete this transaction?",
                               parent=self.top):
            ok, msg = self._ctrl.delete_transaction(t_id)
            if ok:
                self.refresh()
            else:
                messagebox.showerror("Error", msg, parent=self.top)

    def _close(self):
        if self._on_close:
            self._on_close()
        self.top.destroy()
