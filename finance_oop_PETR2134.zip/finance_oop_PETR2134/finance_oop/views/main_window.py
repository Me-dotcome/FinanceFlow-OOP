"""
main_window.py
Main application window - Dashboard view.
Demonstrates: GUI with multiple windows, Observer-style refresh, HCI principles
"""

import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
from controllers.app_controller import AppController
from views.add_edit_dialog import AddEditDialog
from views.rounded_widgets import RoundedButton, RoundedFrame
from models.transaction import Income, Expense


# Palette 
BG       = "#5C5899"   # dark purple — matches gradient start so frames blend
SURFACE  = "#363636"   # dark gray cards
SURFACE2 = "#A8A5D0"   # lavender — kept for combobox dropdown
ACCENT   = "#7C6AF7"
ACCENT2  = "#4ECDC4"
SUCCESS  = "#44CF6C"
DANGER   = "#F05D5E"
TEXT     = "#EB700C"
SUBTEXT  = "#C6C8D3"
BORDER   = "#2A2D3E"
# -----------------------------

# Card dimensions — adjust these two numbers to taste
CARD_HEIGHT  = 90    # fixed height in pixels
CARD_PADDING = 10    # internal padding inside each card

# Budget panel width — guaranteed minimum space on the right
BUDGET_PANEL_WIDTH = 280

# Width (px) below which cards switch from horizontal → vertical layout
BREAKPOINT = 800


class MainWindow:
    """
    Primary application window.
    Cards resize proportionally with the window and reflow to a vertical
    stack when the window becomes too narrow to show them side-by-side.
    """

    def __init__(self, root: tk.Tk, controller: AppController):
        self._root = root
        self._ctrl = controller
        self._selected_month = tk.StringVar()
        self._last_width = 0
        self._card_labels = {}
        self._cards_horizontal = True
        self._left_frame = None
        self._left_win = None
        self._right_frame = None
        self._right_win = None

        self._setup_root()
        self._build_ui()
        self._populate_month_selector()
        self.refresh()

        self._root.bind("<Configure>", self._on_resize)

    # Geometry
    
    def _calculate_geometry2(self, screen_width, screen_height):
        app_width = 1000
        app_height = 600
        x = (screen_width / 2) - (app_width / 2)
        y = (screen_height / 2) - (app_height / 2)
        return f'{app_width}x{app_height}+{int(x)}+{int(y)}'

    # Setup
    def _setup_root(self):
        self._root.title("FinanceFlow - Personal Finance Tracker")
        self._root.geometry(self._calculate_geometry2(self._root.winfo_screenwidth(), self._root.winfo_screenheight()))
        self._root.state("zoomed")
        self._root.minsize(400, 500)
        self._root.configure(bg=BG)
        self._root.option_add("*Font", "Helvetica 10")

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TFrame",       background=BG)
        style.configure("Card.TFrame",  background=SURFACE)
        style.configure("TLabel",       background=BG,      foreground=TEXT)
        style.configure("Card.TLabel",  background=SURFACE, foreground=TEXT)
        style.configure("Muted.TLabel", background=SURFACE, foreground=SUBTEXT)
        style.configure("Treeview",
                        background=SURFACE, foreground=TEXT,
                        fieldbackground=SURFACE, rowheight=28, borderwidth=0)
        style.configure("Treeview.Heading",
                        background=BORDER, foreground=SUBTEXT,
                        font=("Helvetica", 9, "bold"))
        style.map("Treeview", background=[("selected", ACCENT)])
        style.configure("Accent.TButton",
                        background=ACCENT, foreground="white",
                        font=("Helvetica", 10, "bold"), borderwidth=0)
        style.map("Accent.TButton", background=[("active", "#6355D8")])
        style.configure("TCombobox",
                        fieldbackground=SURFACE, background=SURFACE2,
                        foreground=TEXT, selectbackground=ACCENT)

    # UI construction

    def _build_ui(self):
        # Top bar — fixed, stays outside the scroll area
        topbar = tk.Frame(self._root, bg=SURFACE, height=56)
        topbar.pack(fill="x", side="top")

        tk.Label(topbar, text="FinanceFlow",
                 font=("Helvetica", 16, "bold"),
                 bg=SURFACE, fg=ACCENT).pack(side="left", padx=20, pady=12)
        tk.Label(topbar, text="Personal Finance Tracker",
                 font=("Helvetica", 10),
                 bg=SURFACE, fg=SUBTEXT).pack(side="left", pady=12)

        tk.Label(topbar, text="Month:", bg=SURFACE, fg=SUBTEXT,
                 font=("Helvetica", 9)).pack(side="right", padx=(0, 6), pady=12)
        self._month_combo = ttk.Combobox(
            topbar, textvariable=self._selected_month,
            state="readonly", width=10)
        self._month_combo.pack(side="right", pady=12, padx=(0, 20))
        self._month_combo.bind("<<ComboboxSelected>>", lambda e: self.refresh())

        # Scrollable canvas — gradient drawn directly here; no opaque page_frame in front
        self._page_canvas = tk.Canvas(self._root, bg=BG, highlightthickness=0)
        _vscroll = ttk.Scrollbar(self._root, orient="vertical",
                                  command=self._page_canvas.yview)
        _vscroll.pack(side="right", fill="y")
        self._page_canvas.pack(side="left", fill="both", expand=True)
        self._root.bind_all(
            "<MouseWheel>",
            lambda e: self._page_canvas.yview_scroll(-1 * (e.delta // 120), "units")
        )

        # Left frame (summary cards) — placed directly on the gradient canvas
        self._left_frame = tk.Frame(self._page_canvas, bg=BG,
                                     bd=0, highlightthickness=0)
        self._left_win = self._page_canvas.create_window(20, 16,
                                                          window=self._left_frame,
                                                          anchor="nw")
        self._left_frame.bind("<Configure>", self._on_content_resize)

        # Right frame (budget panel) — placed directly on the gradient canvas
        self._right_frame = tk.Frame(self._page_canvas, bg=BG,
                                      bd=0, highlightthickness=0)
        self._right_win = self._page_canvas.create_window(20, 16,
                                                           window=self._right_frame,
                                                           anchor="nw",
                                                           width=BUDGET_PANEL_WIDTH)
        self._right_frame.bind("<Configure>", self._on_content_resize)

        self._page_canvas.bind("<Configure>", self._on_page_canvas_resize)

        self._build_budget_panel(self._right_frame)

        self._summary_outer = tk.Frame(self._left_frame, bg=BG,
                                        bd=0, highlightthickness=0)
        self._summary_outer.pack(fill="x")
        self._summary_frame = tk.Frame(self._summary_outer, bg=BG,
                                        bd=0, highlightthickness=0)
        self._summary_frame.pack(fill="x")

        # Inline content panel — packed on demand, hidden when no panel is open
        self._content_frame = tk.Frame(self._left_frame, bg=BG,
                                        bd=0, highlightthickness=0)

    def _build_budget_panel(self, parent):
        header = tk.Frame(parent, bg=BG, bd=0, highlightthickness=0)
        header.pack(fill="x", pady=(0, 8))

        tk.Label(header, text="Budget Status", bg=BG, fg=TEXT,
                 font=("Helvetica", 11, "bold")).pack(side="left")

        RoundedButton(
            header, text="Actions", command=self._show_action_menu,
            bg=ACCENT, fg="white",
            activebackground=ACCENT, activeforeground="white",
            font=("Helvetica", 9, "bold"),
            padx=14, pady=6, corner_radius=14,
            shadow=True,
        ).pack(side="right")

        self._budget_canvas_frame = tk.Frame(parent, bg=BG,
                                              bd=0, highlightthickness=0)
        self._budget_canvas_frame.pack(fill="both", expand=True)

    def _on_page_canvas_resize(self, event):
        cw, ch = event.width, event.height
        # Position right frame at the right edge with a 20px margin
        right_x = max(cw - 20 - BUDGET_PANEL_WIDTH, 100)
        if self._right_win is not None:
            self._page_canvas.coords(self._right_win, right_x, 16)
        # Give left frame the remaining width (minus gap between the two frames)
        if self._left_win is not None:
            left_w = max(right_x - 32, 50)   # 20px left margin + 12px gap already covered
            self._page_canvas.itemconfig(self._left_win, width=left_w)
        self._update_scrollregion(cw, ch)

    def _on_content_resize(self, _event=None):
        cw = self._page_canvas.winfo_width()
        ch = self._page_canvas.winfo_height()
        self._update_scrollregion(cw, ch)

    def _update_scrollregion(self, cw, ch):
        lh = self._left_frame.winfo_reqheight() if self._left_frame else 0
        rh = self._right_frame.winfo_reqheight() if self._right_frame else 0
        total_h = max(lh, rh) + 32
        scroll_h = max(total_h, ch)
        self._page_canvas.configure(scrollregion=(0, 0, cw, scroll_h))
        self._draw_gradient(cw, scroll_h)

    def _draw_gradient(self, w, h):
        import math
        self._page_canvas.delete("bg_grad")
        bands = min(h, 400)
        if bands == 0:
            return
        for i in range(bands):
            t = i / bands
            wave = (math.sin(t * math.pi * 2.5) * 0.13
                    + math.sin(t * math.pi * 6) * 0.04)
            # #5C5899 (dark purple) → #C8C0F0 (light lavender)
            r = int(max(0, min(255, 92  + (108 + wave * 60) * t)))
            g = int(max(0, min(255, 88  + (104 + wave * 55) * t)))
            b = int(max(0, min(255, 153 + (87  + wave * 35) * t)))
            y0 = h * i // bands
            y1 = h * (i + 1) // bands
            self._page_canvas.create_rectangle(
                0, y0, w, y1,
                fill=f"#{r:02x}{g:02x}{b:02x}",
                outline="", tags="bg_grad"
            )
        self._page_canvas.tag_lower("bg_grad")

    # Responsive resize

    def _on_resize(self, event):
        if event.widget is not self._root:
            return
        w = event.width
        if w == self._last_width:
            return
        self._last_width = w

        want_horizontal = w >= BREAKPOINT
        if want_horizontal != self._cards_horizontal:
            self._cards_horizontal = want_horizontal
            month = self._selected_month.get() or datetime.today().strftime("%Y-%m")
            summary = self._ctrl.get_dashboard_summary(month)
            self._rebuild_cards(summary)

    # Summary cards

    def _rebuild_cards(self, summary: dict):
        """Destroy and recreate the card grid to switch between H and V layout."""
        self._summary_frame.destroy()
        self._summary_frame = tk.Frame(self._summary_outer, bg=BG,
                                        bd=0, highlightthickness=0)
        self._summary_frame.pack(fill="x")
        self._card_labels = {}
        self._render_cards(summary)

    def _render_cards(self, summary: dict):
        
        card_data = [
            ("Balance",  f"£{summary['balance']:,.2f}",
             SUCCESS if summary['balance'] >= 0 else DANGER),
            ("Income",   f"£{summary['income']:,.2f}",  SUCCESS),
            ("Expenses", f"£{summary['expenses']:,.2f}", DANGER),
        ]

        if self._cards_horizontal:
            # Give every column equal weight → cards grow proportionally
            for col in range(len(card_data)):
                self._summary_frame.columnconfigure(col, weight=1, uniform="cards")

            for col, (title, value, colour) in enumerate(card_data):
                outer = RoundedFrame(self._summary_frame, bg=SURFACE,
                     corner_radius=20, padding=10,
                     height=CARD_HEIGHT, shadow=True)
                outer.grid(row=0, column=col, sticky="ew",
                        padx=(0, 10) if col < len(card_data) - 1 else 0,
                        pady=(0, 8))

                tk.Label(outer.body, text=title, bg=SURFACE, fg=SUBTEXT,
                         font=("Helvetica", 9)).pack(anchor="w")
                lbl = tk.Label(outer.body, text=value, bg=SURFACE, fg=colour,
                               font=("Helvetica", 20, "bold"))
                lbl.pack(anchor="w")
                self._card_labels[title] = lbl

            # Alerts: extra column to the right
            alerts = summary.get("budget_alerts", [])
            if alerts:
                n = len(card_data)
                self._summary_frame.columnconfigure(n, weight=1, uniform="cards")
                alert_outer = RoundedFrame(self._summary_frame, bg="#3D1A1A",
                           corner_radius=20, padding=10,
                           height=CARD_HEIGHT, shadow=True)
                alert_outer.grid(row=0, column=n, sticky="ew", padx=(10, 0), pady=(0, 8))
                for b in alerts:
                    tk.Label(alert_outer.body,
                             text=f"⚠  {b.category}: £{b.spent:.2f} / £{b.limit:.2f}",
                             bg="#3D1A1A", fg=DANGER,
                             font=("Helvetica", 9)).pack(anchor="w")

        else:
            # Vertical — single column fills the full width
            self._summary_frame.columnconfigure(0, weight=1)

            for row, (title, value, colour) in enumerate(card_data):
                card = RoundedFrame(self._summary_frame, bg=SURFACE,
                                    corner_radius=20, padding=20, shadow=True)
                card.grid(row=row, column=0, sticky="ew", pady=(0, 8))

                tk.Label(card.body, text=title, bg=SURFACE, fg=SUBTEXT,
                         font=("Helvetica", 9)).pack(anchor="w")
                lbl = tk.Label(card.body, text=value, bg=SURFACE, fg=colour,
                               font=("Helvetica", 20, "bold"))
                lbl.pack(anchor="w")
                self._card_labels[title] = lbl

            # Alerts below the cards
            alerts = summary.get("budget_alerts", [])
            if alerts:
                n = len(card_data)
                alert_card = RoundedFrame(self._summary_frame, bg="#3D1A1A",
                                          corner_radius=20, padding=20, shadow=True)
                alert_card.grid(row=n, column=0, sticky="ew", pady=(0, 8))
                for b in alerts:
                    tk.Label(alert_card.body,
                             text=f"⚠  {b.category}: £{b.spent:.2f} / £{b.limit:.2f}",
                             bg="#3D1A1A", fg=DANGER,
                             font=("Helvetica", 9)).pack(anchor="w")

    def _update_card_values(self, summary: dict):
        """Fast path: update label text/colour without rebuilding widgets."""
        mapping = {
            "Balance":  (f"£{summary['balance']:,.2f}",
                         SUCCESS if summary['balance'] >= 0 else DANGER),
            "Income":   (f"£{summary['income']:,.2f}",  SUCCESS),
            "Expenses": (f"£{summary['expenses']:,.2f}", DANGER),
        }
        for title, (value, colour) in mapping.items():
            if title in self._card_labels:
                self._card_labels[title].config(text=value, fg=colour)

    # Budget panel

    def _refresh_budget_panel(self, summary: dict):
        for w in self._budget_canvas_frame.winfo_children():
            w.destroy()

        budgets = summary.get("budgets", [])
        if not budgets:
            tk.Label(self._budget_canvas_frame,
                     text="No budgets set for this month.",
                     bg=BG, fg=SUBTEXT, wraplength=230).pack(pady=10)
            return

        for b in sorted(budgets, key=lambda x: x.category):
            card = RoundedFrame(self._budget_canvas_frame, bg=SURFACE,
                                corner_radius=12, padding=8, height=60, shadow=True)
            card.pack(fill="x", pady=(0, 8))

            top = tk.Frame(card.body, bg=SURFACE)
            top.pack(fill="x")
            tk.Label(top, text=b.category, bg=SURFACE, fg=TEXT,
                     font=("Helvetica", 9, "bold")).pack(side="left")
            tk.Label(top, text=f"£{b.spent:.0f}/£{b.limit:.0f}",
                     bg=SURFACE, fg=SUBTEXT,
                     font=("Helvetica", 8)).pack(side="right")

            bar_bg = RoundedFrame(card.body, bg=BORDER, corner_radius=8,
                                  padding=0, height=16)
            bar_bg.pack(fill="x", pady=(4, 0))
            bar_bg.update_idletasks()
            bar_w = bar_bg.winfo_width() or 220
            pct = min(b.percent_used / 100, 1.0)
            colour = DANGER if b.is_exceeded else (
                "#F5A623" if pct > 0.75 else SUCCESS)
            RoundedFrame(bar_bg.body, bg=colour, corner_radius=8,
                         padding=0, width=int(bar_w * pct), height=16).pack(side="left")

    # Refresh
    def refresh(self):
        month = self._selected_month.get() or datetime.today().strftime("%Y-%m")
        summary = self._ctrl.get_dashboard_summary(month)
        self._rebuild_cards(summary)
        self._refresh_budget_panel(summary)

    def _populate_month_selector(self):
        months = self._ctrl.get_available_months()
        self._month_combo["values"] = months
        self._selected_month.set(
            months[0] if months else datetime.today().strftime("%Y-%m"))

    # Action menu
    def _show_action_menu(self):
        menu = tk.Menu(self._root, tearoff=0, bg=SURFACE, fg=TEXT,
                       activebackground=ACCENT, activeforeground="white",
                       font=("Helvetica", 9))
        menu.add_command(label="+ Add Income",     command=self._open_add_income,
                         foreground=SUCCESS)
        menu.add_command(label="- Add Expense",    command=self._open_add_expense,
                         foreground=DANGER)
        menu.add_command(label="All Transactions", command=self._open_transactions,
                         foreground=ACCENT)
        menu.add_command(label="Manage Budgets",   command=self._open_budgets,
                         foreground=ACCENT2)
        menu.post(self._root.winfo_pointerx(), self._root.winfo_pointery())

    # Panel helpers

    def _show_panel(self, builder):
        for w in self._content_frame.winfo_children():
            w.destroy()
        self._content_frame.pack(fill="x", pady=(16, 0))
        builder(self._content_frame)

    def _close_panel(self):
        for w in self._content_frame.winfo_children():
            w.destroy()
        self._content_frame.pack_forget()
        self._populate_month_selector()
        self.refresh()

    # Inline panel builders

    def _build_add_panel(self, frame, t_type):
        colour = SUCCESS if t_type == "Income" else DANGER
        cats   = Income.INCOME_CATEGORIES if t_type == "Income" else Expense.EXPENSE_CATEGORIES

        hdr = tk.Frame(frame, bg=BG, bd=0, highlightthickness=0)
        hdr.pack(fill="x", pady=(0, 10))
        tk.Label(hdr, text=f"New {t_type}", bg=BG, fg=colour,
                 font=("Helvetica", 13, "bold")).pack(side="left")
        RoundedButton(hdr, text="✕ Close", command=self._close_panel,
                      bg=SURFACE, fg=SUBTEXT,
                      font=("Helvetica", 8), padx=8, pady=3,
                      corner_radius=10, shadow=True).pack(side="right")

        card = tk.Frame(frame, bg=SURFACE, bd=0, highlightthickness=0)
        card.pack(fill="x")
        inner = tk.Frame(card, bg=SURFACE, bd=0, highlightthickness=0)
        inner.pack(fill="x", padx=16, pady=16)

        def lbl(text):
            tk.Label(inner, text=text, bg=SURFACE, fg=SUBTEXT,
                     font=("Helvetica", 8)).pack(anchor="w")

        def entry(var):
            tk.Entry(inner, textvariable=var, bg="#252837",
                     fg="white", insertbackground="white",
                     relief="flat", font=("Helvetica", 10),
                     width=32).pack(anchor="w", pady=(2, 10), fill="x")

        lbl("Amount (£)")
        amount_var = tk.StringVar()
        entry(amount_var)

        lbl("Description")
        desc_var = tk.StringVar()
        entry(desc_var)

        lbl("Category")
        cat_var = tk.StringVar(value=cats[0])
        ttk.Combobox(inner, textvariable=cat_var, values=cats,
                     state="readonly").pack(anchor="w", pady=(2, 10), fill="x")

        lbl("Date (YYYY-MM-DD)")
        date_var = tk.StringVar(value=datetime.today().strftime("%Y-%m-%d"))
        entry(date_var)

        error_var = tk.StringVar()
        tk.Label(inner, textvariable=error_var, bg=SURFACE, fg=DANGER,
                 font=("Helvetica", 8), wraplength=300).pack(anchor="w")

        def save():
            error_var.set("")
            try:
                amount = float(amount_var.get().strip())
            except ValueError:
                error_var.set("Amount must be a valid number.")
                return
            ok, msg = self._ctrl.add_transaction(
                t_type, amount, desc_var.get().strip(),
                cat_var.get(), date_var.get().strip()
            )
            if ok:
                messagebox.showinfo(
                    f"{t_type} Added",
                    f"{t_type} of £{amount:,.2f} added successfully.",
                    parent=self._root
                )
                amount_var.set("")
                desc_var.set("")
                self.refresh()
            else:
                error_var.set(msg)

        btn_row = tk.Frame(inner, bg=SURFACE, bd=0, highlightthickness=0)
        btn_row.pack(anchor="w", pady=(10, 0))
        RoundedButton(btn_row, text="Save", command=save,
                      bg=colour, fg="white",
                      font=("Helvetica", 9, "bold"),
                      padx=16, pady=5, corner_radius=12,
                      shadow=True).pack(side="left")
        RoundedButton(btn_row, text="Cancel", command=self._close_panel,
                      bg=BORDER, fg=SUBTEXT,
                      font=("Helvetica", 9),
                      padx=16, pady=5, corner_radius=12,
                      shadow=True).pack(side="left", padx=(8, 0))

    def _build_transactions_panel(self, frame):
        hdr = tk.Frame(frame, bg=BG, bd=0, highlightthickness=0)
        hdr.pack(fill="x", pady=(0, 10))
        tk.Label(hdr, text="All Transactions", bg=BG, fg=TEXT,
                 font=("Helvetica", 13, "bold")).pack(side="left")
        RoundedButton(hdr, text="✕ Close", command=self._close_panel,
                      bg=SURFACE, fg=SUBTEXT,
                      font=("Helvetica", 8), padx=8, pady=3,
                      corner_radius=10, shadow=True).pack(side="right")

        flt = tk.Frame(frame, bg=BG, bd=0, highlightthickness=0)
        flt.pack(fill="x", pady=(0, 8))
        tk.Label(flt, text="Filter:", bg=BG, fg=SUBTEXT,
                 font=("Helvetica", 9)).pack(side="left")
        filter_var = tk.StringVar(value="All")

        card = tk.Frame(frame, bg=SURFACE, bd=0, highlightthickness=0)
        card.pack(fill="x")

        cols = ("Date", "Type", "Category", "Description", "Amount")
        tree = ttk.Treeview(card, columns=cols,
                            show="headings", selectmode="browse", height=10)
        for col, w in zip(cols, (90, 70, 120, 220, 90)):
            tree.heading(col, text=col)
            tree.column(col, width=w, anchor="e" if col == "Amount" else "w")
        tree.tag_configure("income",  foreground=SUCCESS)
        tree.tag_configure("expense", foreground=DANGER)
        sb = ttk.Scrollbar(card, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=sb.set)
        tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        def load():
            for r in tree.get_children():
                tree.delete(r)
            f    = filter_var.get()
            txns = self._ctrl.get_all_transactions()
            if f != "All":
                txns = [t for t in txns if t.get_type() == f]
            for t in txns:
                sign = "+" if t.get_type() == "Income" else "−"
                tag  = "income" if t.get_type() == "Income" else "expense"
                tree.insert("", "end", iid=t.id, tags=(tag,), values=(
                    t.date, t.get_type(), t.category,
                    t.description[:40], f"{sign}£{t.amount:,.2f}"
                ))

        for lbl in ("All", "Income", "Expense"):
            tk.Radiobutton(flt, text=lbl, variable=filter_var, value=lbl,
                           command=load, bg=BG, fg=SUBTEXT,
                           selectcolor=BG, activebackground=BG,
                           activeforeground=ACCENT).pack(side="left", padx=6)

        btn_row = tk.Frame(frame, bg=BG, bd=0, highlightthickness=0)
        btn_row.pack(fill="x", pady=(8, 0))

        def edit():
            sel = tree.selection()
            if not sel:
                return
            t = self._ctrl.get_transaction_by_id(sel[0])
            if t:
                dlg = AddEditDialog(self._root, self._ctrl, existing=t)
                self._root.wait_window(dlg.top)
                load()
                self.refresh()

        def delete():
            sel = tree.selection()
            if not sel:
                return
            if messagebox.askyesno("Confirm", "Delete this transaction?",
                                   parent=self._root):
                ok, msg = self._ctrl.delete_transaction(sel[0])
                if ok:
                    load()
                    self.refresh()
                else:
                    messagebox.showerror("Error", msg, parent=self._root)

        RoundedButton(btn_row, text="Edit Selected", command=edit,
                      bg=ACCENT, fg="white",
                      font=("Helvetica", 9, "bold"),
                      padx=12, pady=5, corner_radius=12,
                      shadow=True).pack(side="left", padx=(0, 8))
        RoundedButton(btn_row, text="Delete Selected", command=delete,
                      bg=DANGER, fg="white",
                      font=("Helvetica", 9, "bold"),
                      padx=12, pady=5, corner_radius=12,
                      shadow=True).pack(side="left")
        load()

    def _build_budgets_panel(self, frame):
        month = self._selected_month.get() or datetime.today().strftime("%Y-%m")

        hdr = tk.Frame(frame, bg=BG, bd=0, highlightthickness=0)
        hdr.pack(fill="x", pady=(0, 10))
        tk.Label(hdr, text=f"Budgets — {month}", bg=BG, fg=TEXT,
                 font=("Helvetica", 13, "bold")).pack(side="left")
        RoundedButton(hdr, text="✕ Close", command=self._close_panel,
                      bg=SURFACE, fg=SUBTEXT,
                      font=("Helvetica", 8), padx=8, pady=3,
                      corner_radius=10, shadow=True).pack(side="right")

        form = tk.Frame(frame, bg=SURFACE, bd=0, highlightthickness=0)
        form.pack(fill="x", pady=(0, 10))
        form_inner = tk.Frame(form, bg=SURFACE, bd=0, highlightthickness=0)
        form_inner.pack(fill="x", padx=14, pady=14)

        tk.Label(form_inner, text="Set / Update Budget", bg=SURFACE, fg=TEXT,
                 font=("Helvetica", 10, "bold")).pack(anchor="w", pady=(0, 8))

        row1 = tk.Frame(form_inner, bg=SURFACE, bd=0, highlightthickness=0)
        row1.pack(fill="x")

        expense_cats = ["Food & Groceries", "Bills & Utilities", "Entertainment",
                        "Transport", "Healthcare", "Clothing", "Other"]
        tk.Label(row1, text="Category", bg=SURFACE, fg=SUBTEXT,
                 font=("Helvetica", 8)).grid(row=0, column=0, sticky="w")
        cat_var = tk.StringVar(value=expense_cats[0])
        ttk.Combobox(row1, textvariable=cat_var, values=expense_cats,
                     state="readonly", width=18).grid(row=1, column=0, padx=(0, 10))

        tk.Label(row1, text="Monthly Limit (£)", bg=SURFACE, fg=SUBTEXT,
                 font=("Helvetica", 8)).grid(row=0, column=1, sticky="w")
        limit_var = tk.StringVar()
        tk.Entry(row1, textvariable=limit_var, bg="#252837",
                 fg="white", insertbackground="white", relief="flat",
                 font=("Helvetica", 10), width=10).grid(row=1, column=1)

        error_var = tk.StringVar()

        table = tk.Frame(frame, bg=SURFACE, bd=0, highlightthickness=0)
        table.pack(fill="x")

        b_cols = ("Category", "Limit", "Spent", "Remaining", "% Used", "Status")
        btree = ttk.Treeview(table, columns=b_cols,
                             show="headings", height=7)
        for col, w in zip(b_cols, (130, 65, 65, 80, 55, 90)):
            btree.heading(col, text=col)
            btree.column(col, width=w,
                         anchor="e" if col not in ("Category", "Status") else "w")
        btree.tag_configure("ok",   foreground=SUCCESS)
        btree.tag_configure("warn", foreground="#F5A623")
        btree.tag_configure("over", foreground=DANGER)
        bsb = ttk.Scrollbar(table, orient="vertical", command=btree.yview)
        btree.configure(yscrollcommand=bsb.set)
        btree.pack(side="left", fill="both", expand=True)
        bsb.pack(side="right", fill="y")

        def load():
            for r in btree.get_children():
                btree.delete(r)
            for b in sorted(self._ctrl.get_budgets_for_month(month),
                            key=lambda x: x.category):
                if b.is_exceeded:
                    tag, status = "over", "⚠ Over budget"
                elif b.percent_used > 75:
                    tag, status = "warn", "⚠ Near limit"
                else:
                    tag, status = "ok", "✓ On track"
                btree.insert("", "end",
                             iid=f"{b.category}_{b.month}", tags=(tag,),
                             values=(b.category, f"£{b.limit:.2f}",
                                     f"£{b.spent:.2f}", f"£{b.remaining:.2f}",
                                     f"{b.percent_used}%", status))

        def save():
            error_var.set("")
            try:
                limit = float(limit_var.get().strip())
            except ValueError:
                error_var.set("Limit must be a valid number.")
                return
            ok, msg = self._ctrl.set_budget(cat_var.get(), limit, month)
            if ok:
                limit_var.set("")
                load()
                self.refresh()
            else:
                error_var.set(msg)

        def delete():
            sel = btree.selection()
            if not sel:
                return
            parts = sel[0].rsplit("_", 1)
            if len(parts) == 2 and messagebox.askyesno(
                    "Confirm", f"Delete budget for {parts[0]}?",
                    parent=self._root):
                self._ctrl.delete_budget(parts[0], parts[1])
                load()
                self.refresh()

        RoundedButton(row1, text="Save", command=save,
                      bg=ACCENT2, fg="white",
                      font=("Helvetica", 9, "bold"),
                      padx=10, pady=4, corner_radius=10,
                      shadow=True).grid(row=1, column=2, padx=(10, 0))
        tk.Label(form_inner, textvariable=error_var, bg=SURFACE, fg=DANGER,
                 font=("Helvetica", 8)).pack(anchor="w", pady=(4, 0))

        btn_row = tk.Frame(frame, bg=BG, bd=0, highlightthickness=0)
        btn_row.pack(fill="x", pady=(8, 0))
        RoundedButton(btn_row, text="Delete Selected", command=delete,
                      bg=DANGER, fg="white",
                      font=("Helvetica", 9, "bold"),
                      padx=12, pady=5, corner_radius=12,
                      shadow=True).pack(side="left")
        load()

    # Navigation

    def _open_add_income(self):
        self._show_panel(lambda f: self._build_add_panel(f, "Income"))

    def _open_add_expense(self):
        self._show_panel(lambda f: self._build_add_panel(f, "Expense"))

    def _open_transactions(self):
        self._show_panel(self._build_transactions_panel)

    def _open_budgets(self):
        self._show_panel(self._build_budgets_panel)