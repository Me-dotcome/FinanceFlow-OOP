"""
add_edit_dialog.py
Modal dialog for adding or editing a transaction.
Demonstrates: Input validation, multiple dialogs, encapsulation of form state.
"""

import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
from controllers.app_controller import AppController
from models.transaction import Income, Expense
from views.rounded_widgets import RoundedButton

BG      = "#141410"
SURFACE = "#1C1F2B"
ACCENT  = "#7C6AF7"
SUCCESS = "#44CF6C"
DANGER  = "#F05D5E"
TEXT    = "#3E4157"
SUBTEXT = "#C6C8D3"
BORDER  = "#2A2D3E"
INPUT_BG = "#252837"


class AddEditDialog:
    """
    Reusable modal dialog for creating a new transaction or editing an existing one.
    Accepts an optional existing transaction to pre-populate fields (edit mode).
    """

    def __init__(self, parent, controller: AppController,
                 t_type: str = "Expense", existing=None):
        self._ctrl = controller
        self._existing = existing
        self._t_type = existing.get_type() if existing else t_type

        self.top = tk.Toplevel(parent)
        self.top.title(
            f"{'Edit' if existing else 'Add'} {self._t_type}"
        )
        self.top.geometry("420x360")
        self.top.configure(bg=BG)
        self.top.grab_set()   # Make modal
        self.top.resizable(False, False)

        self._build_ui()

        if existing:
            self._pre_populate(existing)

    # ---------- UI ----------

    def _build_ui(self):
        pad = {"padx": 24, "pady": 6}

        tk.Label(self.top,
                 text=f"{'Edit' if self._existing else 'New'} {self._t_type}",
                 bg=BG, fg=TEXT, font=("Helvetica", 13, "bold")).pack(
            anchor="w", padx=24, pady=(20, 10))

        # Amount
        self._add_label("Amount (£)")
        self._amount_var = tk.StringVar()
        self._add_entry(self._amount_var)

        # Description
        self._add_label("Description")
        self._desc_var = tk.StringVar()
        self._add_entry(self._desc_var)

        # Category
        self._add_label("Category")
        cats = (Income.INCOME_CATEGORIES if self._t_type == "Income"
                else Expense.EXPENSE_CATEGORIES)
        self._cat_var = tk.StringVar(value=cats[0])
        combo = ttk.Combobox(
            self.top, textvariable=self._cat_var,
            values=cats, state="readonly", width=34
        )
        combo.pack(anchor="w", **pad)

        # Date
        self._add_label("Date (YYYY-MM-DD)")
        self._date_var = tk.StringVar(
            value=datetime.today().strftime("%Y-%m-%d")
        )
        self._add_entry(self._date_var)

        # Error label
        self._error_var = tk.StringVar()
        tk.Label(self.top, textvariable=self._error_var,
                 bg=BG, fg=DANGER, font=("Helvetica", 9),
                 wraplength=370).pack(anchor="w", padx=24)

        # Buttons
        btn_frame = tk.Frame(self.top, bg=BG)
        btn_frame.pack(fill="x", padx=24, pady=(10, 0))

        colour = SUCCESS if self._t_type == "Income" else DANGER
        RoundedButton(
            btn_frame, text="Save", command=self._save,
            bg=colour, fg="white",
            font=("Helvetica", 10, "bold"), padx=20, pady=6,
            corner_radius=14
        ).pack(side="left")

        RoundedButton(
            btn_frame, text="Cancel", command=self.top.destroy,
            bg=SURFACE, fg=SUBTEXT,
            font=("Helvetica", 10), padx=20, pady=6,
            corner_radius=14
        ).pack(side="left", padx=(8, 0))

    def _add_label(self, text: str):
        tk.Label(self.top, text=text, bg=BG, fg=SUBTEXT,
                 font=("Helvetica", 8)).pack(anchor="w", padx=24, pady=(8, 0))

    def _add_entry(self, var: tk.StringVar):
        e = tk.Entry(self.top, textvariable=var, bg=INPUT_BG, fg="white",
                     insertbackground="white", relief="flat",
                     font=("Helvetica", 10), width=36)
        e.pack(anchor="w", padx=24, pady=2)

    # ---------- Logic ----------

    def _pre_populate(self, t):
        self._amount_var.set(str(t.amount))
        self._desc_var.set(t.description)
        self._cat_var.set(t.category)
        self._date_var.set(t.date)

    def _save(self):
        self._error_var.set("")

        # Validate amount
        try:
            amount = float(self._amount_var.get().strip())
        except ValueError:
            self._error_var.set("Amount must be a valid number.")
            return

        desc = self._desc_var.get().strip()
        category = self._cat_var.get()
        date = self._date_var.get().strip()

        if self._existing:
            ok, msg = self._ctrl.update_transaction(
                self._existing.id, amount, desc, category, date
            )
        else:
            ok, msg = self._ctrl.add_transaction(
                self._t_type, amount, desc, category, date
            )

        if ok:
            self.top.destroy()
        else:
            self._error_var.set(msg)
