"""
budget_window.py
Secondary window – manage monthly budgets per category.
"""

import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
from controllers.app_controller import AppController
from models.base_transaction import BaseTransaction
from views.rounded_widgets import RoundedButton, RoundedFrame

BG      = "#0F1117"
SURFACE = "#1C1F2B"
ACCENT  = "#7C6AF7"
ACCENT2 = "#4ECDC4"
SUCCESS = "#44CF6C"
DANGER  = "#F05D5E"
TEXT    = "#3E4157"
SUBTEXT = "#C6C8D3"
BORDER  = "#2A2D3E"
INPUT_BG = "#252837"


class BudgetWindow:
    """
    Window for creating, viewing, and deleting monthly budgets.
    """

    def __init__(self, parent, controller: AppController,
                 month: str = None, on_close=None):
        self._ctrl = controller
        self._month = month or datetime.today().strftime("%Y-%m")
        self._on_close = on_close

        self.top = tk.Toplevel(parent)
        self.top.title("Manage Budgets")
        self.top.geometry("640x520")
        self.top.configure(bg=BG)
        self.top.protocol("WM_DELETE_WINDOW", self._close)

        self._build_ui()
        self.refresh()

    def _build_ui(self):
        # Header
        hdr = tk.Frame(self.top, bg=SURFACE, height=50)
        hdr.pack(fill="x")
        tk.Label(hdr, text=f"Budgets - {self._month}",
                 bg=SURFACE, fg=TEXT,
                 font=("Helvetica", 13, "bold")).pack(
            side="left", padx=20, pady=12)

        # Add budget form
        form = RoundedFrame(self.top, bg=SURFACE, corner_radius=14, padding=16)
        form.pack(fill="x", padx=20, pady=(14, 0))

        tk.Label(form.body, text="Set / Update Budget",
                 bg=SURFACE, fg=TEXT,
                 font=("Helvetica", 10, "bold")).grid(
            row=0, column=0, columnspan=4, sticky="w", pady=(0, 8))

        # Category dropdown
        tk.Label(form.body, text="Category", bg=SURFACE, fg=SUBTEXT,
                 font=("Helvetica", 8)).grid(row=1, column=0, sticky="w")
        expense_cats = ["Food & Groceries", "Bills & Utilities", "Entertainment",
                        "Transport", "Healthcare", "Clothing", "Other"]
        self._cat_var = tk.StringVar(value=expense_cats[0])
        ttk.Combobox(form.body, textvariable=self._cat_var,
                     values=expense_cats, state="readonly",
                     width=20).grid(row=2, column=0, padx=(0, 12), sticky="w")

        # Limit entry
        tk.Label(form.body, text="Monthly Limit (£)", bg=SURFACE, fg=SUBTEXT,
                 font=("Helvetica", 8)).grid(row=1, column=1, sticky="w")
        self._limit_var = tk.StringVar()
        tk.Entry(form.body, textvariable=self._limit_var, bg=INPUT_BG,
                 fg="white", insertbackground="white", relief="flat",
                 font=("Helvetica", 10), width=12).grid(row=2, column=1, sticky="w")

        # Save button
        RoundedButton(form.body, text="Save Budget", command=self._save_budget,
                      bg=ACCENT2, fg="white",
                      font=("Helvetica", 9, "bold"), padx=12, pady=4,
                      corner_radius=12).grid(row=2, column=2, padx=(12, 0))

        # Error
        self._error_var = tk.StringVar()
        tk.Label(form.body, textvariable=self._error_var,
                 bg=SURFACE, fg=DANGER,
                 font=("Helvetica", 8)).grid(row=3, column=0, columnspan=4,
                                              sticky="w", pady=(4, 0))

        # Budget list
        tk.Label(self.top, text="Current Budgets",
                 bg=BG, fg=TEXT,
                 font=("Helvetica", 11, "bold")).pack(
            anchor="w", padx=20, pady=(16, 4))

        table_frame = RoundedFrame(self.top, bg=SURFACE, corner_radius=14, padding=8)
        table_frame.pack(fill="both", expand=True, padx=20, pady=(0, 12))

        cols = ("Category", "Limit", "Spent", "Remaining", "% Used", "Status")
        self._tree = ttk.Treeview(table_frame.body, columns=cols,
                                  show="headings", height=10)
        widths = {"Category": 140, "Limit": 80, "Spent": 80,
                  "Remaining": 90, "% Used": 70, "Status": 100}
        for col in cols:
            self._tree.heading(col, text=col)
            self._tree.column(col, width=widths.get(col, 80),
                              anchor="e" if col != "Category" and
                              col != "Status" else "w")
        self._tree.tag_configure("ok", foreground=SUCCESS)
        self._tree.tag_configure("warn", foreground="#F5A623")
        self._tree.tag_configure("over", foreground=DANGER)

        sb = ttk.Scrollbar(table_frame.body, orient="vertical",
                           command=self._tree.yview)
        self._tree.configure(yscrollcommand=sb.set)
        self._tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        # Delete button
        RoundedButton(self.top, text="Delete Selected Budget",
                      command=self._delete_budget,
                      bg=DANGER, fg="white",
                      font=("Helvetica", 9, "bold"), padx=14, pady=5,
                      corner_radius=12).pack(anchor="w", padx=20, pady=(0, 14))

    def refresh(self):
        for row in self._tree.get_children():
            self._tree.delete(row)
        budgets = self._ctrl.get_budgets_for_month(self._month)
        for b in sorted(budgets, key=lambda x: x.category):
            if b.is_exceeded:
                tag, status = "over", "⚠ Over budget"
            elif b.percent_used > 75:
                tag, status = "warn", "⚠ Near limit"
            else:
                tag, status = "ok", "✓ On track"
            self._tree.insert("", "end",
                              iid=f"{b.category}_{b.month}",
                              tags=(tag,), values=(
                b.category,
                f"£{b.limit:.2f}",
                f"£{b.spent:.2f}",
                f"£{b.remaining:.2f}",
                f"{b.percent_used}%",
                status
            ))

    def _save_budget(self):
        self._error_var.set("")
        try:
            limit = float(self._limit_var.get().strip())
        except ValueError:
            self._error_var.set("Limit must be a valid number.")
            return
        ok, msg = self._ctrl.set_budget(
            self._cat_var.get(), limit, self._month
        )
        if ok:
            self._limit_var.set("")
            self.refresh()
        else:
            self._error_var.set(msg)

    def _delete_budget(self):
        sel = self._tree.selection()
        if not sel:
            messagebox.showinfo("Select a row",
                                "Please select a budget to delete.",
                                parent=self.top)
            return
        key = sel[0]  # "Category_YYYY-MM"
        parts = key.rsplit("_", 1)
        if len(parts) != 2:
            return
        category, month = parts
        if messagebox.askyesno("Confirm",
                               f"Delete budget for {category} ({month})?",
                               parent=self.top):
            self._ctrl.delete_budget(category, month)
            self.refresh()

    def _close(self):
        if self._on_close:
            self._on_close()
        self.top.destroy()
