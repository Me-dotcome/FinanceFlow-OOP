"""
test_finance.py
Unit tests for the Personal Finance Tracker.
Run with: python -m pytest tests/test_finance.py -v
"""

import sys
import os
import pytest

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from models.base_transaction import BaseTransaction
from models.transaction import Income, Expense, TransactionFactory
from models.budget import Budget


# ─── BaseTransaction / Income / Expense Tests ────────────────────────────────

class TestIncome:

    def test_income_creation_valid(self):
        t = Income(250.0, "Monthly salary", "Salary", "2026-06-01")
        assert t.amount == 250.0
        assert t.description == "Monthly salary"
        assert t.category == "Salary"
        assert t.get_type() == "Income"

    def test_income_signed_amount_positive(self):
        t = Income(500.0, "Freelance job", "Freelance")
        assert t.get_signed_amount() == +500.0

    def test_income_negative_amount_raises(self):
        with pytest.raises(ValueError):
            Income(-10.0, "Bad", "Salary")

    def test_income_zero_amount_raises(self):
        with pytest.raises(ValueError):
            Income(0, "Zero", "Salary")

    def test_income_amount_rounds_to_two_dp(self):
        t = Income(99.999, "Rounding test", "Other")
        assert t.amount == 100.0

    def test_income_invalid_date_raises(self):
        t = Income(100.0, "Test", "Salary")
        with pytest.raises(ValueError):
            t.date = "not-a-date"

    def test_income_to_dict_round_trip(self):
        t = Income(150.0, "Bonus", "Other", "2026-05-10")
        d = t.to_dict()
        restored = Income.from_dict(d)
        assert restored.amount == t.amount
        assert restored.description == t.description
        assert restored.category == t.category
        assert restored.date == t.date

    def test_income_equality_by_id(self):
        t1 = Income(100.0, "A", "Salary")
        t2 = Income(100.0, "A", "Salary")
        assert t1 != t2  # Different UUIDs


class TestExpense:

    def test_expense_creation_valid(self):
        e = Expense(45.0, "Weekly shop", "Food & Groceries", "2026-06-02")
        assert e.amount == 45.0
        assert e.get_type() == "Expense"

    def test_expense_signed_amount_negative(self):
        e = Expense(30.0, "Bus pass", "Transport")
        assert e.get_signed_amount() == -30.0

    def test_expense_invalid_amount_raises(self):
        with pytest.raises(ValueError):
            Expense(-5.0, "Bad", "Transport")

    def test_expense_to_dict_round_trip(self):
        e = Expense(80.0, "Netflix", "Entertainment", "2026-06-05")
        d = e.to_dict()
        restored = Expense.from_dict(d)
        assert restored.amount == e.amount
        assert restored.category == e.category

    def test_expense_invalid_category_falls_back_to_other(self):
        # Constructor falls back silently
        e = Expense(10.0, "Test", "BOGUS_CATEGORY")
        assert e.category == "Other"


class TestTransactionFactory:

    def test_factory_creates_income(self):
        t = TransactionFactory.create("Income", 200.0, "Wage", "Salary")
        assert isinstance(t, Income)

    def test_factory_creates_expense(self):
        t = TransactionFactory.create("Expense", 50.0, "Groceries",
                                      "Food & Groceries")
        assert isinstance(t, Expense)

    def test_factory_raises_on_unknown_type(self):
        with pytest.raises(ValueError):
            TransactionFactory.create("Dividend", 100.0, "Oops", "Other")

    def test_factory_from_dict_income(self):
        original = Income(120.0, "Test income", "Freelance", "2026-01-15")
        restored = TransactionFactory.from_dict(original.to_dict())
        assert isinstance(restored, Income)
        assert restored.amount == 120.0

    def test_factory_from_dict_expense(self):
        original = Expense(35.0, "Taxi", "Transport", "2026-01-20")
        restored = TransactionFactory.from_dict(original.to_dict())
        assert isinstance(restored, Expense)
        assert restored.amount == 35.0


# ─── Budget Tests ─────────────────────────────────────────────────────────────

class TestBudget:

    def test_budget_creation_valid(self):
        b = Budget("Food & Groceries", 200.0, "2026-06")
        assert b.category == "Food & Groceries"
        assert b.limit == 200.0
        assert b.spent == 0.0

    def test_budget_remaining_calculated(self):
        b = Budget("Transport", 100.0, "2026-06")
        b.add_spending(30.0)
        assert b.remaining == 70.0

    def test_budget_is_exceeded(self):
        b = Budget("Entertainment", 50.0, "2026-06")
        b.add_spending(60.0)
        assert b.is_exceeded is True

    def test_budget_not_exceeded(self):
        b = Budget("Healthcare", 200.0, "2026-06")
        b.add_spending(100.0)
        assert b.is_exceeded is False

    def test_budget_percent_used(self):
        b = Budget("Clothing", 100.0, "2026-06")
        b.add_spending(75.0)
        assert b.percent_used == 75.0

    def test_budget_reset_spending(self):
        b = Budget("Bills & Utilities", 300.0, "2026-06")
        b.add_spending(150.0)
        b.reset_spending()
        assert b.spent == 0.0

    def test_budget_invalid_limit_raises(self):
        with pytest.raises(ValueError):
            Budget("Food & Groceries", -50.0, "2026-06")

    def test_budget_invalid_category_raises(self):
        with pytest.raises(ValueError):
            Budget("BOGUS", 100.0, "2026-06")

    def test_budget_to_dict_round_trip(self):
        b = Budget("Transport", 150.0, "2026-05")
        b.add_spending(40.0)
        restored = Budget.from_dict(b.to_dict())
        assert restored.limit == 150.0
        assert restored.spent == 40.0
        assert restored.month == "2026-05"

    def test_update_transaction_recalculates_new_month_budget(self):
        from controllers.data_store import DataStore

        DataStore._instance = None
        from controllers.app_controller import AppController

        ctrl = AppController()
        ctrl._store._transactions = []
        ctrl._store._budgets = []
        ctrl._store.save = lambda: None

        ctrl.set_budget("Food & Groceries", 100.0, "2026-06")
        ctrl.set_budget("Food & Groceries", 100.0, "2026-07")

        ok, msg = ctrl.add_transaction(
            "Expense", 20.0, "Lunch", "Food & Groceries", "2026-06-10"
        )
        assert ok is True

        before_budget = ctrl.get_budgets_for_month("2026-06")[0]
        assert before_budget.spent == 20.0

        txn = ctrl.get_all_transactions()[0]
        ok, msg = ctrl.update_transaction(
            txn.id, 20.0, "Lunch", "Food & Groceries", "2026-07-10"
        )
        assert ok is True

        assert ctrl.get_budgets_for_month("2026-06")[0].spent == 0.0
        assert ctrl.get_budgets_for_month("2026-07")[0].spent == 20.0


# ─── Polymorphism test ────────────────────────────────────────────────────────

class TestPolymorphism:
    """
    Verifies that Income and Expense are substitutable for BaseTransaction
    and that polymorphic methods behave correctly regardless of subtype.
    """

    def test_get_type_polymorphic(self):
        transactions = [
            Income(100.0, "Pay",     "Salary"),
            Expense(50.0, "Food",    "Food & Groceries"),
            Expense(20.0, "Bus",     "Transport"),
            Income(200.0, "Gig",     "Freelance"),
        ]
        types = [t.get_type() for t in transactions]
        assert types == ["Income", "Expense", "Expense", "Income"]

    def test_signed_amounts_sum_to_balance(self):
        transactions = [
            Income(1000.0, "Salary",   "Salary"),
            Expense(200.0, "Rent",     "Bills & Utilities"),
            Expense(50.0,  "Shopping", "Food & Groceries"),
        ]
        balance = sum(t.get_signed_amount() for t in transactions)
        assert balance == pytest.approx(750.0)

    def test_sorting_by_date(self):
        t1 = Income(100.0, "A", "Salary",  "2026-01-15")
        t2 = Expense(50.0, "B", "Other",   "2026-03-10")
        t3 = Income(200.0, "C", "Freelance","2026-02-20")
        sorted_txns = sorted([t2, t1, t3])
        assert [t.date for t in sorted_txns] == [
            "2026-01-15", "2026-02-20", "2026-03-10"
        ]
